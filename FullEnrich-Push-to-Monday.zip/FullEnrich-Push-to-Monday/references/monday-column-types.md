# Monday.com column types — payload reference

Use this when constructing the `column_values` JSON object for `create_item`. The object is keyed by **column ID** (not title), and each value is formatted per column type.

The `column_values` parameter is a JSON object that gets serialized as a string. Example structure:

```json
{
  "email_mkk1abc": { "email": "jane@acme.com", "text": "jane@acme.com" },
  "phone_mkk2def": "+14155550100",
  "text_mkk3ghi": "Acme Corp"
}
```

## Item name (mandatory, special)

The item name is **not** a column — it's passed as the top-level `item_name` parameter to `create_item`. Plain string.

```json
{
  "board_id": 123456,
  "group_id": "topics",
  "item_name": "Jane Doe",
  "column_values": { ... }
}
```

If empty, skip the item. Monday rejects empty item names.

## text (single-line text)

```json
{ "<column_id>": "Acme Corp" }
```

Plain string. Fallback for company, title, or any text-ish field.

## long_text

```json
{ "<column_id>": { "text": "Long description..." } }
```

Or plain string also works. Use object form for safety.

## email

```json
{ "<column_id>": { "email": "jane@acme.com", "text": "jane@acme.com" } }
```

`text` is the display label (usually same as email). Both required.

If FullEnrich email is missing/null, **omit the column key entirely**.

## phone

```json
{ "<column_id>": { "phone": "+14155550100", "countryShortName": "US" } }
```

Or simpler:

```json
{ "<column_id>": "+14155550100" }
```

Plain string works as fallback. Omit key if missing.

## link (URL)

```json
{ "<column_id>": { "url": "https://linkedin.com/in/jane", "text": "LinkedIn" } }
```

Both `url` and `text` required. `text` is the display label.

## status

```json
{ "<column_id>": { "label": "Working on it" } }
```

⚠️ **Critical rule**: Only use if the label already exists on this status column. Fetch the column's settings (via `get_board_schema` → look at `settings_str` for the column) to see existing labels. If the FullEnrich value doesn't match any existing label exactly (case-sensitive), **skip the field for that contact**. Do not auto-create.

## dropdown

```json
{ "<column_id>": { "labels": ["SaaS", "B2B"] } }
```

Array of label names. Same rule as status — only existing labels.

For single-value dropdown, still pass an array with one element.

## numbers

```json
{ "<column_id>": "87" }
```

Pass as string. Monday parses it. If FullEnrich returns a non-numeric value, omit.

## date

```json
{ "<column_id>": { "date": "2026-04-28" } }
```

ISO format `YYYY-MM-DD`. For datetime:

```json
{ "<column_id>": { "date": "2026-04-28", "time": "14:30:00" } }
```

## checkbox

```json
{ "<column_id>": { "checked": "true" } }
```

Note: `"true"` as **string**, not boolean.

## people

Skip — requires Monday user IDs which FullEnrich doesn't provide.

## tags

```json
{ "<column_id>": { "tag_ids": [12345, 67890] } }
```

Skip — requires tag IDs, not names.

## location

```json
{ "<column_id>": { "address": "Tel Aviv, Israel", "lat": "32.0853", "lng": "34.7818" } }
```

If FullEnrich only returns city name, send just the address as `text` fallback into a regular text column instead — the location column needs lat/lng to render correctly.

## country

```json
{ "<column_id>": { "countryName": "Israel", "countryCode": "IL" } }
```

Both required. If you don't have the country code, skip.

---

## Format checks before sending

- **Item name**: trim whitespace; if empty after trim, skip the contact entirely.
- **Email**: must contain `@` and `.`. Malformed → omit key.
- **Phone**: pass through. Monday is permissive.
- **Status / dropdown**: label must exist on the column; otherwise omit.
- **URL**: should start with `http://` or `https://`. If not, prepend `https://`.
- **Numbers**: must be parseable as a number; otherwise omit.

## Common errors and fixes

| Error | Fix |
|---|---|
| `Column with id X not found` | Column was deleted/renamed since setup. Re-fetch schema and retry. |
| `Invalid value for column type` | Payload shape doesn't match the column type. Check this reference for the right shape. |
| `Status label "X" not found` | Label doesn't exist on the status column. Skip the field (don't auto-create). |
| `Item name cannot be empty` | Skipped contact had no name — should have been filtered out earlier. |
| `Board not found` | Stored board ID is invalid. Trigger re-setup. |

## Tip: how to read `settings_str` for status/dropdown

`get_board_schema` returns columns with a `settings_str` field that's a JSON string. Parse it to find existing labels:

```json
// settings_str for a status column might look like:
{
  "labels": {
    "0": "Working on it",
    "1": "Done",
    "2": "Stuck"
  }
}
```

Use the **values** (label names), not the keys (numeric IDs), to match against FullEnrich data. Then in the payload use `{ "label": "Done" }`.