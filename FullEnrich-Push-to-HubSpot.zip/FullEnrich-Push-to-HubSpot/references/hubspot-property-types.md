# HubSpot property types — payload reference

Use this when constructing the `properties` object for `crm-create-object`, `crm-update-object`, or `crm-batch-create-objects`. The object is keyed by HubSpot's **internal property `name`** (not the human-readable `label`).

⚠️ **All values in HubSpot's API are sent as STRINGS**, even numbers and booleans. HubSpot converts internally based on the property type. This is unlike Notion/Attio/Airtable where types are explicit JSON.

Example structure for upserting a contact:

```json
{
  "objectType": "contacts",
  "idProperty": "email",
  "id": "jane@acme.com",
  "properties": {
    "firstname": "Jane",
    "lastname": "Doe",
    "email": "jane@acme.com",
    "phone": "+14155550100",
    "jobtitle": "VP Marketing",
    "company": "Acme Corp"
  }
}
```

## string (text properties)

```json
{ "firstname": "Jane" }
```

Plain string. Used for most text properties: `firstname`, `lastname`, `email`, `phone`, `jobtitle`, `company`, etc.

If FullEnrich returns null/empty, omit the key entirely.

## number

```json
{ "num_associated_deals": "5" }
```

⚠️ **Stringified**, not actual number. HubSpot's API expects `"5"` not `5`. If you pass the actual number, it usually still works but stringify to be safe.

## bool

```json
{ "hs_email_optout": "true" }
```

Stringified booleans: `"true"` or `"false"`. Not relevant for FullEnrich data.

## enumeration (single-select dropdown)

```json
{ "industry": "COMPUTER_SOFTWARE" }
```

⚠️ **Use the option's internal `value`, NOT the `label`.** When you call `crm-list-properties`, each enumeration property has an `options` array like:

```json
{
  "name": "industry",
  "type": "enumeration",
  "options": [
    { "label": "Computer Software", "value": "COMPUTER_SOFTWARE" },
    { "label": "E-commerce", "value": "ECOMMERCE" }
  ]
}
```

To match FullEnrich's `industry: "Computer Software"`:
1. Find the option where `label` (or `value`) matches.
2. Pass the `value` in the payload.

If no match found → skip the field. Don't auto-create options (would silently clutter the user's HubSpot setup).

## enumeration (multi-checkbox)

```json
{ "favorite_topics": "topic_a;topic_b" }
```

Semicolon-separated string of values (NOT array). Same option-existence rule.

## date

```json
{ "key_date": "2026-04-28" }
```

ISO date format `YYYY-MM-DD`. Or Unix timestamp in milliseconds at midnight UTC.

## datetime

```json
{ "createdate": "2026-04-28T14:30:00.000Z" }
```

ISO 8601 datetime with milliseconds and `Z`. Or Unix timestamp in milliseconds.

Most datetime properties (`createdate`, `lastmodifieddate`, `hs_lastmodifieddate`) are read-only — don't try to set them.

## phone_number

Internally stored as `string`, but HubSpot may auto-format. Pass in E.164 (`+14155550100`) when possible:

```json
{ "phone": "+14155550100" }
```

## Standard contact properties — quick reference

These are the most common standard properties on the Contacts object. Names are stable across all HubSpot accounts:

| Internal name | Type | Notes |
|---|---|---|
| `firstname` | string | First name |
| `lastname` | string | Last name |
| `email` | string | Primary email — used as `idProperty` for upsert |
| `phone` | string | Primary phone |
| `mobilephone` | string | Mobile-specific phone |
| `company` | string | **Display-only** company name on the contact (separate from associated Company record) |
| `jobtitle` | string | Job title |
| `industry` | enumeration | Often pre-populated; use option values |
| `city` | string | City |
| `state` | string | State/region |
| `country` | string | Country |
| `address` | string | Street address |
| `zip` | string | Postal code |
| `website` | string | Personal/company website |
| `hs_linkedin_url` | string | LinkedIn profile URL |
| `twitterhandle` | string | Twitter handle (no `@`) |
| `lifecyclestage` | enumeration | ⚠️ Triggers workflows. Don't set automatically. |
| `hs_lead_status` | enumeration | ⚠️ Triggers workflows. Don't set automatically. |
| `hubspot_owner_id` | string (user ID) | ⚠️ Triggers notifications. Don't set automatically. |

**Note on `company` (string) vs Company record (associated object)**:
The `company` string property on a Contact is just a text label — it doesn't link the contact to a Company record. The actual association happens through HubSpot's automatic company-association feature (via email domain), or via explicit association API calls. For this skill, just set the `company` string property; HubSpot handles the actual record link automatically via email domain.

## Format checks before sending

- **firstname / lastname**: trim whitespace; if both empty AND email is missing, skip the contact (HubSpot won't create a contact with neither).
- **email**: must contain `@` and `.`. Malformed → omit. If using `idProperty: "email"`, malformed email blocks upsert entirely — skip the contact.
- **phone**: pass through; HubSpot is permissive.
- **enumeration**: option must exist on property; otherwise omit.
- **All values**: convert to string before sending (HubSpot expects strings everywhere).

## Common errors and fixes

| Error | Fix |
|---|---|
| `Property X does not exist` | Property name doesn't match (case-sensitive!). Re-fetch via `crm-list-properties` and use exact `name` field. |
| `INVALID_OPTION` on an enumeration | Option `value` doesn't exist on the property. Skip the field. |
| `CONTACT_EXISTS` on create (without upsert) | Email already exists. Use `idProperty: "email"` to upsert instead. |
| `ID_PROPERTY_VALUE_REQUIRED` | When using `idProperty`, the `id` field must be in the payload. Add it. |
| `INVALID_EMAIL` | Email format malformed. Skip this contact for upsert. |
| `LIST_NOT_FOUND` on adding to list | Stored list ID is invalid. Trigger re-setup. |
| `OBJECT_NOT_IN_LIST_TYPE` | The list isn't a Contact list (could be a Company or Deal list). Pick a different list. |
| `ACTIVE_LIST_CANNOT_ADD_RECORDS` | The list is a dynamic/active list. Pick a static list instead. |

## Tip: Standard Contacts properties vs custom

Most HubSpot accounts have ~50 standard Contact properties + custom ones added by the user. Strategy:
1. Try the standard internal name first (e.g. `jobtitle` for job title).
2. If `crm-list-properties` shows that name exists, use it.
3. Otherwise, fall back to fuzzy matching against `label` (display name) of all properties.
4. If nothing matches, skip the field.

## Tip: how to handle `company` vs Company record

When you set `company: "Acme Corp"` on a contact:
- The text "Acme Corp" appears in HubSpot's contact card under the Company field.
- This is **separate** from associating the contact to a Company record.
- HubSpot's auto-association feature handles the actual record linking — based on the **email domain**, not the `company` string.

So setting both `email: "jane@acme.com"` AND `company: "Acme Corp"` is the right move:
- Email triggers domain-based auto-association → Company record link.
- `company` string fills the display field on the contact.

Both are useful and don't conflict.