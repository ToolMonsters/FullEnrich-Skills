# Attio attribute types — payload reference

Use this when constructing the `values` object for `upsert-record`, `create-record`, or `add-record-to-list`'s `entry_values`. The object is keyed by **attribute `api_slug`** (or `attribute_id` UUID).

Example structure for a person upsert:

```json
{
  "object": "people",
  "matching_attribute": "email_addresses",
  "values": {
    "name": "Doe, Jane",
    "email_addresses": ["jane@acme.com"],
    "phone_numbers": ["+14155550100"],
    "company": "acme.com",
    "job_title": "VP Marketing"
  }
}
```

## personal_name (the name attribute on People)

Two formats accepted, simple is preferred:

```json
{ "name": "Doe, Jane" }
```

⚠️ **Last name FIRST**, separated by `, ` (comma-space). For "Jane Doe", pass `"Doe, Jane"`.

If FullEnrich returned `firstname: "Jane"` and `lastname: "Doe"`, format as `"${lastname}, ${firstname}"`.

Object format (verbose, all 3 fields required):

```json
{
  "name": [{
    "first_name": "Jane",
    "last_name": "Doe",
    "full_name": "Jane Doe"
  }]
}
```

If FullEnrich only returns `full_name`, try to split on the last space — last word as `last_name`, the rest as `first_name`. Or use `full_name` as both first and last in fallback.

## email_address (multiselect)

```json
{ "email_addresses": ["jane@acme.com"] }
```

**Always an array**, even for one email. The slug on People is typically `email_addresses` (plural).

This is also the standard `matching_attribute` for upsert.

If multiple emails from FullEnrich (rare): `["work@x.com", "personal@y.com"]`.

## phone_number (multiselect)

```json
{ "phone_numbers": ["+14155550100"] }
```

Always array. Pass in E.164 format if possible (with country code). Attio is permissive but stricter formats avoid downstream issues.

## text

```json
{ "job_title": "VP Marketing" }
```

Plain string. Used for things like `job_title`, `headline`, custom text fields.

## url

```json
{ "linkedin": "https://linkedin.com/in/janedoe" }
```

Must include the `https://` scheme. If FullEnrich returns `linkedin.com/in/x` without scheme, prepend `https://`.

## select (single value)

```json
{ "industry": "Software" }
```

Pass the **option title** (case-sensitive). Use the UUID only if you have it.

⚠️ **Critical**: Only use if the option exists. Check `list-attribute-definitions` → the attribute's `options` array. If FullEnrich returns `"Fintech"` but options are `["SaaS", "E-commerce", "B2B"]`, **skip** the field.

## status (single value, like select but with workflow semantics)

```json
{ "stage": "Working on it" }
```

Same rule as select — only existing statuses.

## select with multiselect=true

```json
{ "tags": ["Lead", "Enriched"] }
```

Array of option titles. Same rule about existing options.

## record_reference (linking to another record, e.g. company)

**Three formats** supported, in order of preference:

### Format A — Simple (recommended for FullEnrich workflow)

For `company` on People (single-object reference):

```json
{ "company": "acme.com" }
```

Pass the company's **domain** as a string. Attio matches against existing companies by domain. If no company exists with that domain, Attio **auto-creates** one. This is exactly what we want for FullEnrich workflows.

### Format B — By matching attribute

```json
{
  "company": [{
    "target_object": "companies",
    "domains": [{ "domain": "acme.com" }]
  }]
}
```

Same outcome, more verbose. Use only if format A fails.

### Format C — By record ID (only if you already have the company UUID)

```json
{
  "company": [{
    "target_object": "companies",
    "target_record_id": "0f0cc00c-2c97-4130-8b42-3b5c7dfea4c6"
  }]
}
```

For the FullEnrich workflow, **always prefer Format A** with the company domain. If FullEnrich didn't return a domain (just a name), use Format A with the name as a string fallback — Attio will try to match by name.

## location

Simple format (preferred):

```json
{ "primary_location": "Tel Aviv, Israel" }
```

Object format if you have structured data:

```json
{
  "primary_location": {
    "line_1": "1 Infinite Loop",
    "locality": "Cupertino",
    "region": "CA",
    "postcode": "95014",
    "country_code": "US"
  }
}
```

FullEnrich usually returns just a string like `"Tel Aviv, Israel"` — use the simple format.

## number

```json
{ "employee_count": 100 }
```

Pass as actual number, not string.

## currency

```json
{ "deal_value": 10000 }
```

Number, in the attribute's configured currency. Not relevant for FullEnrich contact pushes.

## checkbox

```json
{ "is_active": true }
```

Boolean (real boolean, not string).

## date

```json
{ "founded_date": "2024-01-15" }
```

ISO 8601 date format.

## timestamp

```json
{ "created_at": "2024-01-15T10:30:00Z" }
```

ISO 8601 datetime.

## rating

```json
{ "priority": 3 }
```

Number 0-5.

## actor_reference (workspace member)

```json
{ "owner": "user@example.com" }
```

Workspace member email or UUID. Not typically populated from FullEnrich data.

## interaction

NOT WRITABLE — these attributes are read-only (last contact, last activity, etc.). Never include.

## domain (on Companies object)

```json
{ "domains": ["acme.com"] }
```

Array of domain strings. Used as `matching_attribute` for upserting companies (not relevant when pushing People).

---

## Format checks before sending

- **personal_name**: trim whitespace; if empty, skip the contact.
- **email_address**: must contain `@` and `.`; malformed → omit.
- **phone_number**: pass through; Attio is permissive.
- **select / status**: option must exist on attribute; otherwise omit.
- **url**: must start with `http://` or `https://`; prepend `https://` if missing.
- **record_reference (company)**: prefer domain over name when both available.

## Common errors and fixes

| Error | Fix |
|---|---|
| `Attribute X is not defined` | Slug doesn't match. Re-fetch via `list-attribute-definitions` and use the exact `api_slug`. |
| `Value for matching_attribute must be provided in values payload` | Upsert requires the matching attribute (usually `email_addresses`) inside `values`. Make sure it's there. |
| `Select option "X" not found` | Option doesn't exist on the select. Skip the field. |
| `Multiple records match the matching_attribute value` | Two People records share the same email — Attio data integrity issue. Surface to user. |
| `List not found` | Stored list ID is invalid. Trigger re-setup. |
| `List parent object mismatch` | The list expects companies but you're adding a person record. Check list config. |

## Tip: how to find the right slug

Attribute slugs are NOT necessarily the display name. The attribute "Job title" might have slug `job_title` or `title` depending on workspace config. Always call `list-attribute-definitions` first and use the returned `api_slug` verbatim.

For matching FullEnrich → Attio attributes:
1. Get the list of slugs from the schema.
2. Normalize both sides (lowercase, strip underscores/hyphens/spaces).
3. Match. If no match, skip silently.