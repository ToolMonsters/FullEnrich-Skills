# Notion property types — payload reference

Use this when constructing the `properties` object for `notion-create-pages`. Covers all property types you're likely to encounter when adapting to user databases.

## Title (mandatory — exactly one per database)

Every Notion database has exactly one title property. The name varies ("Name", "Contact", "Lead", "Person"...) — fetch the schema to get the exact name and type=`title`.

```json
{
  "<title property name>": {
    "title": [
      { "text": { "content": "Jane Doe" } }
    ]
  }
}
```

If the title content would be empty, skip the contact entirely — Notion rejects pages with empty titles.

## Email

```json
{
  "Email": { "email": "jane@acme.com" }
}
```

If missing/null, **omit the key entirely** rather than passing empty string (which errors). Validate format: must contain `@` and `.`.

## Phone number

```json
{
  "Phone": { "phone_number": "+1 415 555 0100" }
}
```

Permissive format. Omit key if missing.

## Rich text (most common fallback)

```json
{
  "Company": {
    "rich_text": [
      { "text": { "content": "Acme Corp" } }
    ]
  }
}
```

For empty values, pass `"rich_text": []` (empty array), not null.

## URL

```json
{
  "LinkedIn": { "url": "https://linkedin.com/in/jane" }
}
```

Useful when user maps LinkedIn URL or company website to a URL-typed column.

## Select

```json
{
  "Industry": { "select": { "name": "SaaS" } }
}
```

⚠️ **Critical rule**: Only use if the option already exists on the property. Fetch the property's `options` array from the schema first. If the FullEnrich value doesn't match an existing option name (case-sensitive), skip the field for that contact rather than auto-creating new options. Auto-creating clutters the user's database.

## Multi-select

```json
{
  "Tags": {
    "multi_select": [
      { "name": "Lead" },
      { "name": "Enriched" }
    ]
  }
}
```

Same option rule as select.

## Number

```json
{
  "Score": { "number": 87 }
}
```

If FullEnrich returns score as a string, convert with `parseInt` / `parseFloat`. If invalid, omit.

## Checkbox

```json
{
  "Verified": { "checkbox": true }
}
```

## Date

```json
{
  "Last Contact": {
    "date": { "start": "2026-04-28" }
  }
}
```

ISO 8601 format. For just a date, no time component needed.

## People

Skip — requires Notion user IDs which FullEnrich doesn't provide.

## Files & media, Relation, Rollup, Formula, Created/Last edited

Skip these — either auto-computed by Notion or require complex IDs.

---

## Format checks before sending

- **Title**: trim whitespace; if empty, skip the contact entirely.
- **Email**: must contain `@` and `.`. Malformed → omit (or fall back to rich_text if column type allows).
- **Phone**: pass through as-is.
- **Select / multi_select**: option must exist on property; otherwise omit.
- **URL**: should start with `http://` or `https://`. If not, prepend `https://`.

## Common errors and fixes

| Error | Fix |
|---|---|
| `body.properties.X.title should be defined` | Property mapped to title is wrong — find the actual `type: "title"` property in the schema. |
| `Invalid property identifier` | Property name doesn't match schema exactly (case-sensitive). Use `notion-fetch` output verbatim. |
| `Email is not a valid email` | Malformed value from FullEnrich. Omit the key. |
| `select.name is not a valid option` | Option doesn't exist. Skip the field for this contact. |
| `Could not find database` | Stored database ID is invalid (deleted/moved). Trigger re-setup. |
