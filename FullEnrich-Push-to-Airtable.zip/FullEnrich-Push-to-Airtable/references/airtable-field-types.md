# Airtable field types — payload reference

Use this when constructing the `fields` object for `create_record`, `update_record`, or batch equivalents.

The `fields` object is keyed by **field name** (the human-readable name you see in Airtable, case-sensitive). Field IDs (starting with `fld...`) also work and are more stable, but names are what most Airtable MCPs accept by default.

Example structure for creating a contact record:

```json
{
  "base_id": "appAbC123XyZ",
  "table_id": "tblXyZ789AbC",
  "fields": {
    "Name": "Jane Doe",
    "Email": "jane@acme.com",
    "Phone": "+14155550100",
    "Company": "Acme Corp",
    "Job Title": "VP Marketing"
  }
}
```

## singleLineText

```json
{ "Name": "Jane Doe" }
```

Plain string. Most common type. Length limit ~100k chars but keep reasonable.

## multilineText (long text)

```json
{ "Notes": "Multiple lines\nof text are fine here" }
```

Plain string with `\n` for line breaks.

## email

```json
{ "Email": "jane@acme.com" }
```

Plain string. Airtable validates the format and will reject malformed emails.

If FullEnrich returns null/empty, **omit the field key entirely** rather than passing empty string.

## phoneNumber

```json
{ "Phone": "+1 415 555 0100" }
```

Plain string. Airtable is permissive — passes through whatever format you send. Prefer E.164 (`+14155550100`) when available.

## url

```json
{ "LinkedIn": "https://linkedin.com/in/janedoe" }
```

Must include `https://` or `http://`. If FullEnrich returns `linkedin.com/in/x` without scheme, prepend `https://`.

## singleSelect

```json
{ "Industry": "Software" }
```

Pass the **option name** (case-sensitive, exact match).

⚠️ **Critical rule**: Only use if the option exists. Check the field's `options.choices` array from `get_base_schema`. If FullEnrich returns `"Fintech"` but options are `["SaaS", "E-commerce", "B2B"]`, **skip the field** for that contact.

By default, Airtable does NOT auto-create new options via API. Some MCPs expose a `typecast: true` parameter to allow this — use only if explicitly requested.

## multipleSelects

```json
{ "Tags": ["Lead", "Enriched"] }
```

Array of option names. Same option-existence rule as singleSelect.

## number

```json
{ "Score": 87 }
```

Pass as **actual number** (integer or float), not a string. Airtable will reject `"87"` for number fields.

If FullEnrich returns a string score, parse with `parseInt`/`parseFloat`. If parse fails, omit.

## currency

```json
{ "Deal Value": 10000 }
```

Number. The currency symbol is configured at the field level in Airtable; the API just takes the number.

## percent

```json
{ "Conversion Rate": 0.42 }
```

Decimal — `0.42` for 42%, NOT `42`.

## checkbox

```json
{ "Verified": true }
```

Boolean (real boolean, not string).

## date

```json
{ "Last Contacted": "2026-04-28" }
```

ISO 8601 date format `YYYY-MM-DD`.

## dateTime

```json
{ "Last Activity": "2026-04-28T14:30:00.000Z" }
```

ISO 8601 datetime, UTC. Include the trailing `Z`.

## rating

```json
{ "Priority": 4 }
```

Integer 0 to max (max is configured per field, typically 5).

## duration

```json
{ "Call Duration": 1800 }
```

Number of seconds.

## linkedRecord (link to another table)

```json
{ "Company": ["recXyz789AbC"] }
```

Array of **record IDs** (strings starting with `rec...`) from the linked table.

⚠️ **This is hard**: you can't pass a company name like `"Acme Corp"` directly. You need to first look up the company's record ID via `list_records` on the linked table, then pass the ID.

For the FullEnrich workflow, **skip linked-record fields by default** unless the user explicitly maps them. Linking a contact to a company auto-magically requires a multi-step lookup (find company by name in the linked table → use its ID) which is fragile.

If FullEnrich returns a company name and the user really wants to link, surface as: *"Skipped 'Company (linked)' field. To populate, you'd need a separate Companies table — let me know if you want me to set up that workflow."*

## attachment

Skip — requires file uploads via URLs and is rarely useful for FullEnrich data.

## user (collaborator)

Skip — requires Airtable user IDs which FullEnrich doesn't provide.

## formula / rollup / lookup / count / autoNumber / createdTime / lastModifiedTime / createdBy / lastModifiedBy / button

NOT WRITABLE — these are computed by Airtable. Never include in `fields`.

## externalSyncSource

NOT WRITABLE.

---

## Format checks before sending

- **Primary field**: trim whitespace; if empty, skip the contact entirely.
- **email**: must contain `@` and `.`; malformed → omit key.
- **phoneNumber**: pass through; Airtable is permissive.
- **singleSelect / multipleSelects**: option must exist on the field; otherwise omit.
- **url**: must start with `http://` or `https://`; prepend `https://` if missing.
- **number / currency / rating**: must be a valid number; if FullEnrich returns string, parse first.
- **date / dateTime**: must be ISO format; if FullEnrich returns a different format, normalize first.

## Common errors and fixes

| Error | Fix |
|---|---|
| `INVALID_VALUE_FOR_COLUMN` on a select | Option doesn't exist. Skip the field (or use `typecast: true` if MCP supports it). |
| `INVALID_RECORD_FIELDS` | Field name doesn't match table schema (case-sensitive!). Re-fetch schema and use exact name. |
| `ROW_DOES_NOT_EXIST` on update | The record_id you passed doesn't exist in this table. Probably a stale find result — re-search. |
| `NOT_FOUND` on the table | Stored table_id is invalid (table deleted/moved). Trigger re-setup. |
| `INVALID_REQUEST` (rate limit) | Hit 5 req/sec. Wait a moment and retry. |
| `Cannot accept the provided value for field` (linked record) | Field is a linked-record type. Pass `["rec..."]` array of IDs, not a string. |

## Tip: how to check if a select option exists

`get_base_schema` returns each field with details. For a singleSelect, the structure looks like:

```json
{
  "id": "fld123",
  "name": "Industry",
  "type": "singleSelect",
  "options": {
    "choices": [
      { "id": "sel123", "name": "SaaS", "color": "blueLight2" },
      { "id": "sel456", "name": "E-commerce", "color": "greenLight2" }
    ]
  }
}
```

Match against `options.choices[].name` (case-sensitive).

## Tip: filterByFormula for dedup search

For finding an existing record by email:

```
{Email}='jane@acme.com'
```

- Field name in single curly braces: `{Email}`
- Value in single quotes: `'jane@acme.com'`
- Escape single quotes in the value: `O'Brien` → `O\'Brien`
- Multiple conditions: `AND({Email}='x@y.com', {Status}='Active')`

Common gotcha: spaces in field names. `{Job Title}` works fine; double quotes don't.