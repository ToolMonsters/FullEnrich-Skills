---
name: FullEnrich - Push to Airtable
description: Automatically send FullEnrich search and enrichment results into the user's Airtable base with zero friction. On first use, asks the user once for an Airtable URL (which contains both the base ID and table ID) and whether to auto-push or confirm — then memorizes this. On every subsequent FullEnrich search or enrich call, the skill upserts records into Airtable (deduplicating by email), adapting to whatever fields exist in the user's table. Use this skill whenever FullEnrich's `search_contact`, `enrich_contact`, `enrich_contact_async`, or `enrich_bulk` returns results, even if the user did not mention Airtable in the current message — the skill handles everything.
---

# FullEnrich - Push to Airtable

One-time setup (paste an Airtable URL), then auto-push. Deduplicates on email automatically. Adapts to any user's Airtable schema.

## Required MCPs

- **FullEnrich MCP** — `https://mcp.fullenrich.com/mcp`
- **Airtable MCP** — Airtable MCP server (community/Composio implementation; expects standard tools: `list_bases`, `list_tables`, `get_base_schema`, `list_records`, `create_record`, `update_record`, or equivalents)

If either is missing, tell the user which one to connect and stop.

## Memory model

This skill relies on Claude's memory to remember setup across conversations. After `/setup`, use the `memory_user_edits` tool to persist:

- `FullEnrich-Airtable skill: target = base "<base name>" / table "<table name>" (base_id: <appXXX>, table_id: <tblYYY>)`
- `FullEnrich-Airtable skill: push mode = auto` *(or `push mode = confirm`)*

Before doing anything in this skill, check userMemories for these two lines. If both are present, skip setup and go straight to the push flow.

---

## Flow A — First use (no memory yet)

When FullEnrich returns results AND no setup is in memory, run `/setup` inline before pushing:

### Step 1: Ask for the Airtable URL

> Before I push these to Airtable, quick one-time setup. Paste the URL of your Airtable table (just open the table in your browser and copy the URL from the address bar).

Wait for the URL.

### Step 2: Parse the URL and resolve names

Airtable URLs follow this pattern:
```
https://airtable.com/{base_id}/{table_id}/{view_id?}/{record_id?}
```

Where:
- `base_id` starts with `app` (e.g. `appAbC123XyZ`)
- `table_id` starts with `tbl` (e.g. `tblXyZ789AbC`)
- `view_id` (optional) starts with `viw` — ignore
- `record_id` (optional) starts with `rec` — ignore

Extract `base_id` and `table_id` from the URL. If either is missing, ask the user to paste a URL that includes a table.

Then call `get_base_schema` (or equivalent — fetch base structure) with the base_id to:
- Get the **base name** (for memory display)
- Get the **table name** (for memory display)
- Get the **field list** with names and types

If the URL is malformed or the base/table can't be resolved, ask the user to paste it again.

### Step 3: Ask for push preference

> Got it — base **`<base name>`**, table **`<table name>`**. One last thing: after future searches/enrichments, do you want me to push automatically, or confirm with you first each time?
>
> 1. Push automatically
> 2. Confirm before each push

### Step 4: Save to memory

Use `memory_user_edits` with command `add` to persist both lines. Confirm briefly:

> Saved. From now on, FullEnrich results will go to **`<table name>`** in **`<base name>`** <auto / after confirmation>. Duplicates are handled automatically (dedup on email).

### Step 5: Push the current batch

Continue immediately to **Flow C — Push** below.

---

## Flow B — Subsequent use (memory present)

When FullEnrich returns results AND memory has the target:

- If push mode = `auto` → go straight to Flow C, push, report.
- If push mode = `confirm` → end your message with one short line: *"Push these N contacts to **`<table name>`** in Airtable?"*. On confirmation, run Flow C.

Don't re-run setup. Don't ask which fields to map. Just adapt to the schema and push.

---

## Flow C — Push (the actual work)

### 1. Fetch the table schema

Call `get_base_schema` with the stored base_id. Find the table matching the stored table_id, and extract:
- **Field list** with `name`, `type`, and (for select/status) `options`
- The **primary field** (first field in the table — every Airtable table has one, it's the field shown in the row's name column)

### 2. Identify the email field for dedup

Find a field that maps to email by fuzzy matching field names (case-insensitive, ignore spaces/underscores/hyphens):
- patterns: `email`, `e-mail`, `work email`, `professional email`, `mail`, `email address`

If no email-like field exists, dedup is impossible — fall back to "always create new" mode and mention this in the report: *"⚠️ No email field found; created N new records without dedup."*

### 3. Adapt the FullEnrich payload to the user's fields

For each FullEnrich contact, build a `fields` object by **scanning the table's actual fields** and matching what FullEnrich provides.

**Primary field** (mandatory — the row needs a value here, it's how Airtable displays the row):
- If the primary field is name-like (matches `name`, `full name`, `contact`, etc.) → set to FullEnrich's `full_name`.
- If the primary field is email-like → set to FullEnrich's email.
- Otherwise → set to FullEnrich's `full_name` as fallback.
- If the primary value would be empty, skip the contact.

**Other fields** — fuzzy match on field name (case-insensitive, ignore spaces/underscores/hyphens):

| FullEnrich field | Field name patterns to match |
|---|---|
| `full_name` | name, full name, contact, person, prospect, lead |
| `email` (work email) | email, e-mail, work email, professional email, mail |
| `phone` | phone, phone number, mobile, tel, telephone, cell |
| `company.name` | company, company name, organization, account, employer, business |
| `job_title` | title, job title, role, position, headline |
| `linkedin_url` | linkedin, linkedin url, profile, social, li |
| `industry` | industry, sector, vertical |
| `location` | location, city, country, region, geo |
| `seniority` | seniority, level, rank |

Match **as many fields as the table has columns for**. Skip silently when no match. **Never** create new fields.

### 4. Format values per Airtable field type

See `references/airtable-field-types.md` for exact JSON shapes. Quick rules:

- `singleLineText` / `multilineText` → plain string
- `email` → plain string (validated email format)
- `phoneNumber` → plain string
- `url` → plain string with `https://` scheme
- `singleSelect` → `"Option Name"` — **only if the option exists** on that select. Skip otherwise.
- `multipleSelects` → `["Option1", "Option2"]` — same rule.
- `number` → actual number (not stringified)
- `checkbox` → boolean
- `date` → `"YYYY-MM-DD"` ISO format

### 5. Dedup logic (find-then-update / find-then-create)

Airtable has no native upsert, so for each contact:

**a) Search for existing record by email**

If FullEnrich provides an email AND an email field exists in the table:
- Call `list_records` with a `filterByFormula` like:
  ```
  {Email}='jane@acme.com'
  ```
  (use the actual field name, in single curly braces; escape single quotes in the email if any)
- If the result returns 1+ records, take the first one's `record_id`.

**b) Update or create**

- **If a matching record was found** → call `update_record` with that record_id and the mapped `fields` object. Use **PATCH semantics** (only the fields you provide get updated; existing values for other fields are preserved). Counts as an "updated" record in the report.
- **If no match was found** (or no email available) → call `create_record` with the mapped `fields` object. Counts as a "new" record.

For records without an email at all (e.g. raw search results), always create.

### 6. Execute and rate-limit awareness

Airtable's API has rate limits (5 requests/second per base). For batches >10 contacts, this matters.

- Many Airtable MCPs expose batch endpoints (e.g. `create_records` plural, accepting up to 10 records at once). Use the batch endpoint if available.
- If only single-record endpoints are available, call them sequentially. For >20 contacts, mention progress in the report.

Don't worry about retries unless an explicit rate-limit error comes back.

### 7. Report

Keep it tight — 1-2 lines max:

> ✓ 12 contacts synced to **Leads** in Airtable → [open table](https://airtable.com/appXXX/tblYYY)

If some were duplicates that got updated:

> ✓ 12 contacts processed (8 new, 4 updated existing) → [open table]

If some failed or were skipped:

> ✓ 10 pushed, 2 skipped (no name) → [open table]

If no email field exists in the table:

> ✓ 12 new records created in **Leads** → [open table]
> ⚠️ Heads up: no email field found in this table, so no dedup was possible. To enable dedup next time, add an email-type field.

---

## Changing the setup

If the user says any of:
- "change the Airtable table"
- "use a different base/table"
- "switch to confirm mode" / "switch to auto"
- "/setup" or "/reset"

Re-run Flow A and overwrite the memory lines using `memory_user_edits` with command `replace`.

If the user says "stop pushing to Airtable" or similar, use `memory_user_edits` with command `remove` to delete both lines, and confirm: *"Auto-push disabled. Run /setup again anytime to re-enable."*

---

## Edge cases

**Async enrichment not finished** — If `enrich_contact_async` or `enrich_bulk` was called but `get_enrichment_results` hasn't been polled, poll it first. Push only the ready ones; mention pending count if any remain.

**Empty results** — 0 contacts returned from FullEnrich → don't trigger anything, stay silent.

**Search vs enrich** — Both trigger the push. Search results often lack email — those records get created (no dedup possible per record). Mention in the report when this happens.

**Table doesn't have an email field at all** — Skip dedup for the whole batch, always create. Surface this in the report (see step 7).

**Companies (`search_company`)** — This skill is contact-focused. If the user explicitly asks to push companies, do it manually using a similar pattern.

**Single-select / multi-select option not found** — If FullEnrich returns `industry: "Fintech"` but the singleSelect field has only `["SaaS", "E-commerce"]`, skip that field for that contact. Don't auto-create options (Airtable would error on creation unless explicitly enabled).

**Linked records (e.g. linked Companies table)** — If the table has a linked-record field for company, the value must be an array of record IDs from the linked table, not a string. This is complex — skip linked-record fields by default and surface in the report: *"Skipped 'Company (linked)' field — linked-record fields not auto-populated."* The user can map manually.

**URL parsing fails** — If the user pastes something that isn't an Airtable URL (or pastes a base URL without a table), tell them what to do: *"Open the specific table you want in Airtable, then copy the URL from the browser. It should look like `https://airtable.com/app.../tbl.../...`."*

**Stored base/table invalid** — If `get_base_schema` returns "not found" or the table_id no longer exists in the base, tell the user the table may have been deleted or moved, and offer `/setup`.

**Rate limiting** — If you hit Airtable's 5 req/sec limit, wait briefly and retry. Don't surface this to the user unless it persists.

---

## What this skill does NOT do

- ❌ Create or modify Airtable bases or tables (we adapt to existing schemas)
- ❌ Add fields to the user's table
- ❌ Auto-create select options
- ❌ Populate linked-record fields automatically (too complex/risky without explicit mapping)
- ❌ Push companies automatically (contacts only)
- ❌ Delete or archive existing records

---

## References

- `references/airtable-field-types.md` — Airtable field type payload shapes for `create_record` / `update_record`. Read when constructing the `fields` payload and unsure of the JSON shape for a given field type.
